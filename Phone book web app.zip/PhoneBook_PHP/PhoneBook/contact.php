
<html>
<head>
<title>Phone Book</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<div id = "main">
  <h1> Phone Book</h1>
  <?php 
  
  include_once 'menu-main.php';
  ?>
  
 
  <h2 class="chead">Developer: Bakhtiar Wazir</h2>
<p class="cpara">bakhtiar.wazir1@gmail.com</p>
<h2 class="chead">Brought To You By</h2>
<p class="cpara"><a href="http://code-projects.org">code-projects.org</a></p>
</div>
</body>
</html>
